function deferFilterjQuery() {
    if (window.jQuery && window.$) {
        $(function(){
          // On load/reload
          var pt_on_load = function() {
            // Accordion
            
              
              $('.filter-menu .filter-group').not('.has_group_selected, .refine-header, .pt-display-dropdown').toggleClass('pt-group-expanded');
              
          	

          	// Search
            $('.pt-display-search').not('.has_group_selected').find('input.fm-search-box').show();

          	// Drop downs
            $('.pt-display-dropdown').each(function( index ) {
                $(this).find('h4').after($(this).find('.filter-clear'));
            });

            $('.pt-display-dropdown .scroll-content').each(function( index ) {
                if($(this).find('li.selected').length) {
                    var selected = $.map(
                        $(this).find('li.selected a'),
                            function(element){
                                return $(element).text();
                            }
                      ).join(", ");

                  if (selected.length < 30) {
                    $(this).before('<div class="menu-trigger">' + selected +'</div>');
                  } else {
                     $(this).before('<div class="menu-trigger">' + $(this).find('li.selected').length + ' Selected </div>');
                  }
                }
                else {
                    $(this).before('<div class="menu-trigger">'+ $(this).closest('.filter-group').find('h4').text() +'</div>');
                }
            });

          	// View more
            

            $('.filter-menu li a').attr('title', function() {
              return ($(this).closest('li').hasClass('selected') ? "Clear filter: " : "Add filter: ") + $(this).text();
            });
          }

          pt_on_load();

          // Mobile filter button
          

          // Accordion
          
          $(document).on('click', '.filter-menu h4', function(e){
            $(this).closest('.filter-group').not('.has_group_selected, .refine-header, .pt-display-dropdown').toggleClass('pt-group-expanded');
            e.preventDefault();
          });
          

          // Search
          $(document).on('keyup', '.filter-group input.fm-search-box', function () {
            var value = this.value.toLowerCase();
            $(this).closest('.filter-group').find('li').each(function () {
              if ($(this).text().toLowerCase().search(value) > -1) {
                $(this).show(100);
              } else {
                $(this).hide(100);
              }
            });
          });

          // Drop downs
          $(document).on('click','.pt-display-dropdown .menu-trigger',function() {
            $(this).next('.scroll-content').css('top', $(this).position().top + $(this).height() + 1).css('left', $(this).position().left);
            $(this).next('.scroll-content').slideToggle('fast');
          });

          $(document).on('mouseleave', '.pt-display-dropdown .scroll-content', function() {
            $(this).slideUp('fast');
          });

          // Apply button
          
          $('.filter-menu').append('<div class="filter-group"><button class="pt-apply pt-apply-disabled">Apply</button></div>');
          $(document).on('click', '.pt-apply', function(e) {
            if ($('.filter-menu').data('current-url')) {
              window.location = $('.filter-menu').data('current-url');
            }
          });
          $(document).on('click', '.filter-group li.collection-container a, .filter-group a.filter-clear', function(e) {
            e.preventDefault();
            var current_url = $(this).attr('href');
            $('.filter-menu').data('current-url', current_url).fadeTo('slow', 0.8);
            $.get(current_url, function( data ) {
              var elem = $(data).find('.filter-menu');
              $('.filter-menu').replaceWith(elem).fadeTo('fast', 1.0);
              $('.filter-menu').data('current-url', current_url).append('<div class="filter-group"><button class="pt-apply">Apply</button></div>');
              pt_on_load();
              $('.filter-menu .pt-mobile-header a').trigger('click');
            });
          });
          

          // Ajax
          
      });
    }
    else {
        setTimeout(function() { deferFilterjQuery() }, 50);
    }
}

deferFilterjQuery();
